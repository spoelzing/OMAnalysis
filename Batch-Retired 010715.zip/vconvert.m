% Original vconvert altered on 12/15/2012 by Sharon George to read the Data files from the
% Ultima Camera



function [] = vconvert(Newpath,Path,hname,binning,corv);

%%%%%%%%%%%%%%%%%%%%%%%%
% READ THE HEADER FILE %
%%%%%%%%%%%%%%%%%%%%%%%%
% for f=1:size(fname,2)
%     namecomp=fname{1,f};
%     if strcmp(namecomp(end),'h')==1
%         hname=namecomp;
%     else
%         fname1{1,f}=namecomp;
%     end
% end
% fname=fname1;
fid=fopen(fullfile(Path,hname),'r');
line=fgetl(fid);
line=fgetl(fid);
temp=find(line=='/');
xdim=str2num(line(temp(1,3)-3:temp(1,3)-1));    %x-dimension of data array
xdim1=xdim-28;
ydim1=str2num(line(temp(1,4)-3:temp(1,4)-1));    %y-dimension of data array
frpfile=str2num(line(end-2:end));               %Number of frames per file

line=fgetl(fid);
line=fgetl(fid);
temp=find(line=='=');
datetime=line(temp+1:end);

line=fgetl(fid);
temp=find(line=='=');
frames=str2num(line(temp+1:end));              %Total number of frames

line=fgetl(fid);
line=fgetl(fid);
temp=find(line=='=');
stime=line(temp+3:end-4);
srate=1/(str2num(stime)*10^-3);

line=fgetl(fid);
line=fgetl(fid);
line=fgetl(fid);
temp=find(line=='=');
gain=line(temp+1:end);


for tempcount=1:1:20
    line=fgetl(fid);
end

temp=find(line=='=');
Comments=line(temp+1:end);

fclose(fid);




%%%%%%%%%%%%%%%%%%%%%%%%
% READ THE GSD FILE    %
%%%%%%%%%%%%%%%%%%%%%%%%
% fid = fopen([Filename]);
n=xdim1*ydim1;
ecg4=[];
file=[];
fname={};
fname1d={};
fname2d={};


fname1=dir(Path(1,1:end-1));
count=size(fname1,1);
fname1d={};
fname2d={};

for i=1:count
line=getfield(fname1(i,1),'name');
line=char(line);

ext='.rsd';

if length(line)>3 
    temp=(find(line=='('))-1;
    temp1=length(line)-3;
    
    if strcmp(line(1,temp1:end),ext)==1 
        temp2=find(line==')');
        digits=line(temp+2:temp2-1);
        
        if line(1:temp)==hname(1:end-4)
            if size(digits)==1
              fname1d=[fname1d line(1,1:end)];
            else
                fname2d=[fname2d line(1,1:end)];
            end
        end
    end
end
end
fname=[fname1d fname2d];
% htemp=find(hname,'.')
% i=1;
% fname1=[Path hname(htemp-1),'(i)'];
% while exist fname1
% i=i+1;
% fname=[fname fname1];
% end


for f=1:size(fname,2)
fid1=fopen(fullfile(Path,fname{1,f}),'r');
a=fread(fid1,'int16');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% To Read The Extra Channels %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
count1=1;
count2=13;

while count2<=3276800
    ecg(1,count1)=a(count2,1);
    count1=count1+1;
    count2=count2+12800;    %SR=1/20th of recording SR.
end
ecg4=vertcat(ecg4,ecg');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% To Read The Image %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

b=zeros(128,25600);

for n=1:1:25599
    for m=1:128
        b(m,n)=a((n*128+m),1);
    end
end
output=zeros(100,100,256);

i=0;


for k=1:256

       
        for j=1:100
            output(:,j,k)=b(20:119,i+j);
                   
        end
        
        
       
   i=i+100;
  
end

file=cat(3,[file],[output]);

end


frdata(:,:,:)=file(:,:,:);
% frdata=flipdim(frdata,1);
breakthefile=1;
broken=0;
onward=1;
frdataoriginal=frdata;
oframes=frames;


while breakthefile==1 & onward==1;
%     if broken>0;
%         frdata=frdataoriginal;
%     end
%     
if oframes>6000 & onward==1;
    if broken+1:broken+5000<frames;
        frdata=frdataoriginal(:,:,broken*5000+1:broken*5000+5000);
        ecg5=ecg4(broken*5000+1:broken*5000+5000,1);
        frames=5000;
    else
        clear frdata fbdata
        frdata=frdataoriginal(:,:,broken*5000+1:end); 
        ecg5=ecg4(broken*5000+1:end,1);
        [x,y,frames]=size(frdata);
        onward=0;
    end
    breakthefile==1;
    broken=broken+1;
    changefilename=1;
else
    breakthefile==0;
    changefilename=0;
    onward=0;
    ecg5=ecg4;
end

if binning>1
    for col=1:ydim1/binning 
        for row=1:xdim1/binning
            rngr1=binning*(row-1)+1;
            rngr2=binning*(row-1)+binning;
            rngc1=binning*(col-1)+1;
            rngc2=binning*(col-1)+binning;
            if corv==2
                if fname(end-4)=='A'
                    tmp=squeeze(sum(sum(frdata(rngr1:rngr2,rngc1:rngc2,:)))/binning^2);
%                   tmp(2:end)=tmp(2:end)-tmp(1);
                    tmp(2:end)=tmp(2:end);
                    fbdata(row,col,:)=tmp;
                    fbdata(row,col,1)=0;
                    
                    if row==6 & 1==6
                        figure(3)
                        plot(tmp-max(tmp(2:end)))
                    end
                
                else
                    tmp=sum(sum(frdata(rngr1:rngr2,rngc1:rngc2,:)))/binning^2;
%                   fbdata(row,col,:)=tmp-min(tmp(2:end))+1;
                    fbdata(row,col,:)=tmp;
                    fbdata(row,col,1)=1;
                   
                end
            else
                fbdata(row,col,:)=sum(sum(frdata(rngr1:rngr2,rngc1:rngc2,:)))/binning^2;
                fbdata(row,col,:)=sum(sum(frdata(rngr1:rngr2,rngc1:rngc2,:)))/binning^2+frdata(row,col,1);
                fbdata(row,col,1)=fbdata(row,col,2);
            end
        end
    end
else
    fbdata=frdata;
    jump=(squeeze(fbdata(:,:,2)-fbdata(:,:,1)));
    mjump=mean(mean(jump));
    sjump=std(std(jump));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Voltage or Calcium. Calcium has a mirror shift      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[xdim, ydim, frames]=size(fbdata);

% if corv==1
%     for count=1:xdim
% 
%         fbdatatemp(count,:,:)=fbdata(xdim+1-count,:,:);
%     end
%     fbdata=fbdatatemp;
% end

% imagesc(fbdata(:,:,1))
% pause


% csize = size(exchdata);
% chsize = csize(1)/4;
Data=reshape(fbdata,[xdim*ydim],frames);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         SAVE DATA FILE                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Filename = horzcat(Newpath,hname);
temp=find(Filename=='.');
if changefilename==1;
    Filenamef=[Filename(1:temp-1),'_',num2str(broken),Filename(temp)];
else
    Filenamef=[Filename(1:temp-1)];
end
% Filename=[Filename(1:temp)];
% mesg=(['Processing ',Filenamef]);
% disp(mesg)
fid3=fopen(Filenamef,'w','b');
% The lines below have been causing errors with Zeng_Log. They have been
% removed on 10/26/2011 by SP. 
% fprintf(fid3,'COLUMN BINARY FILE\n');
% fprintf(fid3,'2t260c0c0e\n');

Data=Data';

% Dataw = [Data,echan1',echan2',echan3',echan4'];

Dataw=[Data,ecg5];
for count=1:frames
   fwrite(fid3,Dataw(count,:),'int16');
end
fclose(fid3);

n=size(Dataw,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   SAVE HEADER FILE                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if changefilename==1;
    Filenameh=[Filename(1:temp-1),'_',num2str(broken),'.h'];
else
    Filenameh=[Filename(1:temp-1),'.h'];
end
fid2=fopen(Filenameh,'w');

fprintf(fid2,['subject ',Comments,'\n']);
fprintf(fid2,'preparation unknown\n');
fprintf(fid2,'data %s\n',datetime);
fprintf(fid2,'gain %s\n', gain);
fprintf(fid2,'srate %i\n',srate);
fprintf(fid2,'samples %i\n',frames);
fprintf(fid2,'chans %i\n',n);
fprintf(fid2,['comment ',Comments,'\n']);
if binning==1
    fprintf(fid2,'lut /usr/local/lut/Ultima\n');
elseif binning==2
    fprintf(fid2,'lut /usr/local/lut/Ultima50x50\n');
elseif binning==4
    fprintf(fid2,'lut /usr/local/lut/Ultima25x25\n');
end    
fprintf(fid2,'fhigh 0\n');
fprintf(fid2,'user Steven Poelzing\n');
fprintf(fid2,'mag 0\n');
fprintf(fid2,'temp 0\n');
fprintf(fid2,'pressure 0\n');
fprintf(fid2,'flow 0\n');
fprintf(fid2,'stimulator SS\n');
fprintf(fid2,'timeing 00ms\n');
fprintf(fid2,'strength 0ms,0mA\n');
fclose(fid2);


end
fclose(fid1);

